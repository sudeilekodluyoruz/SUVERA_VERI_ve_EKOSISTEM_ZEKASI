from pathlib import Path
import sys
import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from src.data import load_app_data, latest_country_features
from src.model import train_model, predict_investment, NUMERIC_FEATURES, make_training_frame

st.set_page_config(page_title="SUVERA | Data & Ecosystem Intelligence", page_icon="S", layout="wide", initial_sidebar_state="expanded")

# SUVERA visual system: warm neutrals, muted sage and deep petrol.
BG = "#F4F3EE"
SURFACE = "#FFFFFF"
INK = "#263F42"
MUTED = "#71817D"
TEAL = "#6F9990"
LINE = "#E2E6DF"

st.markdown(f"""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap');
:root {{ --suvera-bg:{BG}; --suvera-ink:{INK}; --suvera-muted:{MUTED}; --suvera-teal:{TEAL}; }}
.stApp {{ background:var(--suvera-bg); color:var(--suvera-ink); font-family:'DM Sans',sans-serif; }}
[data-testid="stHeader"] {{ background:rgba(244,243,238,.92); }}
[data-testid="stSidebar"] {{ background:#E9EEE8; border-right:1px solid #DDE4DC; }}
[data-testid="stSidebar"] * {{ color:{INK}; }}
[data-testid="stSidebar"] [data-testid="stRadio"] label {{ padding:7px 10px; border-radius:9px; }}
[data-testid="stSidebar"] [aria-checked="true"] {{ background:#D8E5DD; }}
.block-container {{ max-width:1440px; padding-top:2.1rem; padding-bottom:3rem; }}
.brand-mark {{ font-family:'Manrope',sans-serif; font-weight:800; font-size:1.65rem; letter-spacing:.12em; color:{INK}; }}
.brand-sub {{ font-size:.66rem; letter-spacing:.13em; color:{MUTED}; margin-top:-4px; }}
.hero {{ background:linear-gradient(115deg,#E5ECE5 0%,#EAF0EB 58%,#DCE9E2 100%); border:1px solid #DCE5DC; border-radius:18px; padding:28px 32px; margin:0 0 22px 0; }}
.hero-kicker {{ color:#68837B; font-size:.72rem; font-weight:700; letter-spacing:.15em; text-transform:uppercase; margin-bottom:8px; }}
.hero h1 {{ font-family:'Manrope',sans-serif; color:{INK}; font-size:2rem; font-weight:800; line-height:1.2; margin:0 0 9px 0; }}
.hero p {{ color:#60736E; font-size:.98rem; margin:0; max-width:760px; }}
.section-kicker {{ color:{TEAL}; font-size:.7rem; font-weight:700; letter-spacing:.13em; text-transform:uppercase; margin:5px 0 5px; }}
.section-title {{ color:{INK}; font-family:'Manrope',sans-serif; font-size:1.25rem; font-weight:700; margin:0 0 5px; }}
.section-desc {{ color:{MUTED}; font-size:.88rem; margin:0 0 15px; }}
div[data-testid="stMetric"] {{ background:{SURFACE}; border:1px solid {LINE}; border-radius:14px; padding:17px 18px; box-shadow:0 2px 8px rgba(40,65,58,.025); }}
div[data-testid="stMetricLabel"] p {{ color:{MUTED}; font-size:.78rem; }}
div[data-testid="stMetricValue"] {{ color:{INK}; font-family:'Manrope',sans-serif; font-size:1.65rem; }}
[data-testid="stVerticalBlockBorderWrapper"] {{ border-color:{LINE}; border-radius:14px; background:{SURFACE}; }}
.stButton>button, .stDownloadButton>button {{ background:#668D83; color:white; border:1px solid #668D83; border-radius:10px; font-weight:600; padding:.55rem 1rem; }}
.stButton>button:hover, .stDownloadButton>button:hover {{ background:#52786F; border-color:#52786F; color:white; }}
.stSelectbox div[data-baseweb="select"]>div, .stNumberInput input {{ background:#fff; border-color:#DDE4DC; border-radius:9px; }}
.stTabs [data-baseweb="tab"] {{ color:{MUTED}; }}
.stTabs [aria-selected="true"] {{ color:{INK}; border-bottom-color:{TEAL}; }}
div[data-testid="stAlert"] {{ border-radius:11px; }}
.suvera-note {{ background:#EAF1EC; border:1px solid #D8E5DC; border-left:4px solid #7FA397; padding:13px 16px; border-radius:10px; color:#49635C; font-size:.87rem; }}
.suvera-footer {{ border-top:1px solid {LINE}; margin-top:38px; padding-top:16px; color:#87928D; font-size:.75rem; }}
small, .stCaption {{ color:{MUTED}; }}
</style>
""", unsafe_allow_html=True)

@st.cache_resource(show_spinner="Modeller hazırlanıyor...")
def get_model(_tables):
    return train_model(_tables)

@st.cache_data(show_spinner=False)
def get_data():
    return load_app_data()

try:
    tables = get_data()
    bundle = get_model(tables)
except Exception as exc:
    st.error(f"Proje verileri veya model hazırlanamadı: {exc}")
    st.stop()

# Sidebar identity and navigation
with st.sidebar:
    st.markdown('<div class="brand-mark">SUVERA</div><div class="brand-sub">DATA & ECOSYSTEM INTELLIGENCE</div>', unsafe_allow_html=True)
    st.markdown("\n")
    st.caption("KEŞİF ALANI")
    page = st.radio("Sayfalar", ["Genel Bakış", "Türkiye Profili", "Yatırım Tahmini", "Model Performansı", "Veri Merkezi"], label_visibility="collapsed")
    st.markdown("---")
    st.caption("THE WORLD OF AI, THROUGH DATA.")
    st.caption("Veri dönemi · 2016–2025")

investment = tables["FactYatirim"].copy()
countries = tables["DimUlke"].copy()
development = tables["FactKalkinma"].copy()
models_data = tables["FactModel"].copy()

# Consistent page header
page_meta = {
    "Genel Bakış": ("EKOSİSTEME BAKIŞ", "Yapay zekâ ekosistemini verilerle keşfet.", "Yatırım eğilimlerini, öne çıkan ülkeleri ve küresel görünümü tek yerde incele."),
    "Türkiye Profili": ("ÜLKE PROFİLİ", "Türkiye'nin yapay zekâ ekosistemi.", "Yatırım ve kalkınma göstergelerini dünya medyanıyla karşılaştır; kaynakta olmayan veriyi sıfır saymadan göster."),
    "Yatırım Tahmini": ("MAKİNE ÖĞRENMESİ", "Yatırım eğilimini keşfet.", "Bir ülke seç, göstergeleri incele ve modelin ürettiği tahmini senaryolarla değerlendir."),
    "Model Performansı": ("MODEL DEĞERLENDİRMESİ", "Tahminlerin ne kadar başarılı olduğunu gör.", "Modelleri aynı test dönemi üzerinde karşılaştır; hata ölçülerini ve sınırları birlikte değerlendir."),
    "Veri Merkezi": ("VERİ & KAYNAK", "Analizin dayandığı verileri incele.", "Kullanılan tabloları filtrele, değişkenleri tanı ve analiz verilerini dışa aktar."),
}
kicker, headline, subtitle = page_meta[page]
st.markdown(f'<div class="hero"><div class="hero-kicker">{kicker}</div><h1>{headline}</h1><p>{subtitle}</p></div>', unsafe_allow_html=True)


def money_short(value):
    value = float(value)
    if abs(value) >= 1e12: return f"${value/1e12:,.2f} trilyon"
    if abs(value) >= 1e9: return f"${value/1e9:,.1f} milyar"
    if abs(value) >= 1e6: return f"${value/1e6:,.1f} milyon"
    return f"${value:,.0f}"


def style_chart(fig, height=360):
    fig.update_layout(
        height=height, paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font=dict(family="DM Sans, sans-serif", color=INK, size=12),
        margin=dict(l=12, r=16, t=55, b=12),
        title=dict(font=dict(family="Manrope, sans-serif", size=15, color=INK), x=0.02),
        legend=dict(bgcolor="rgba(0,0,0,0)", orientation="h", y=1.08, x=0),
        hoverlabel=dict(bgcolor="#FFFFFF", bordercolor=LINE, font_color=INK),
    )
    fig.update_xaxes(showgrid=False, zeroline=False, linecolor=LINE, tickfont=dict(color=MUTED))
    fig.update_yaxes(gridcolor="#E9EDE8", zeroline=False, linecolor="rgba(0,0,0,0)", tickfont=dict(color=MUTED))
    return fig


if page == "Genel Bakış":
    total = investment["YatirimUSD"].sum()
    country_count = investment["ISO3"].nunique()
    latest_year = int(investment["Yil"].max())
    latest_total = investment.loc[investment.Yil == latest_year, "YatirimUSD"].sum()
    model_count = int((models_data.BuyukModelKumulatif > 0).sum())
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Kayıtlı toplam yatırım", money_short(total))
    m2.metric("Yatırım kaydı bulunan ülke", f"{country_count}")
    m3.metric("İncelenen dönem", f"{int(investment.Yil.min())}–{latest_year}")
    m4.metric("Büyük model kaydı", f"{model_count}")

    st.markdown('<div class="section-kicker">KÜRESEL EĞİLİM</div><div class="section-title">Yatırımlar zaman içinde nasıl değişti?</div><div class="section-desc">Kaynakta pozitif yatırım kaydı bulunan ülke-yılların toplamı.</div>', unsafe_allow_html=True)
    left, right = st.columns([1.45, 1])
    with left:
        yearly = investment.groupby("Yil", as_index=False).YatirimUSD.sum()
        fig = px.area(yearly, x="Yil", y="YatirimUSD", markers=True,
                      labels={"Yil":"Yıl", "YatirimUSD":"Yatırım (USD)"})
        fig.update_traces(line_color=TEAL, fillcolor="rgba(169,196,184,.38)", marker=dict(color=TEAL, size=7), hovertemplate="Yıl: %{x}<br>Yatırım: %{y:$,.0f}<extra></extra>")
        style_chart(fig, 370)
        with st.container(border=True): st.plotly_chart(fig, use_container_width=True)
    with right:
        top = investment.groupby("ISO3", as_index=False).YatirimUSD.sum().merge(countries[["ISO3","UlkeTR"]], on="ISO3", how="left").nlargest(10,"YatirimUSD").sort_values("YatirimUSD")
        fig = px.bar(top, x="YatirimUSD", y="UlkeTR", orientation="h", labels={"YatirimUSD":"Yatırım (USD)","UlkeTR":"Ülke"})
        fig.update_traces(marker_color="#91B3A7", hovertemplate="%{y}<br>%{x:$,.0f}<extra></extra>")
        style_chart(fig, 370)
        with st.container(border=True): st.plotly_chart(fig, use_container_width=True)

    st.markdown('<div class="section-kicker">ÖNE ÇIKAN VERİLER</div><div class="section-title">Ekosistemden kısa notlar</div>', unsafe_allow_html=True)
    c1, c2 = st.columns(2)
    top_country = top.sort_values("YatirimUSD", ascending=False).iloc[0]
    with c1, st.container(border=True):
        st.markdown("**Yatırımda ilk sıradaki ülke**")
        st.markdown(f"### {top_country.UlkeTR}")
        st.caption(f"Kayıtlı toplam: {money_short(top_country.YatirimUSD)}")
    with c2, st.container(border=True):
        st.markdown("**Veri kapsamı**")
        st.markdown(f"### {len(development):,} ülke-yıl gözlemi")
        st.caption("Kalkınma göstergeleri tablosunda yer alan kayıt sayısı.")
    st.markdown('<div class="suvera-note">Veri notu: Kaynakta bir ülke-yıl için yatırım kaydı bulunmaması, o yıl yatırımın sıfır olduğu anlamına gelmez. Bu nedenle eksik kayıtlar sıfır yatırım olarak yorumlanmamıştır.</div>', unsafe_allow_html=True)

elif page == "Türkiye Profili":
    TR, REF_YEAR = "TUR", 2023

    # Yatırım göstergeleri (FactYatirim + FactKalkinma)
    totals = investment.groupby("ISO3").YatirimUSD.sum().sort_values(ascending=False)
    tr_total = totals.get(TR, np.nan)
    rank = int(totals.index.get_loc(TR)) + 1 if TR in totals.index else None
    pooled = investment.merge(development[["ISO3", "Yil", "Nufus"]], on=["ISO3", "Yil"]).dropna(subset=["Nufus"])
    per_cap = lambda d: d.YatirimUSD.sum() / d.Nufus.sum() if len(d) else np.nan
    tr_pc, world_pc = per_cap(pooled[pooled.ISO3 == TR]), per_cap(pooled)

    st.markdown('<div class="section-kicker">YATIRIM</div><div class="section-title">Türkiye\'de özel yapay zekâ yatırımı</div><div class="section-desc">Kaynakta pozitif yatırım kaydı bulunan yıllar; sabit 2021 $ (CSET).</div>', unsafe_allow_html=True)
    c1, c2, c3 = st.columns(3)
    c1.metric("Toplam yapay zekâ yatırımı", "Veri yok" if pd.isna(tr_total) else money_short(tr_total))
    c2.metric("Kişi başına yatırım", "Veri yok" if pd.isna(tr_pc) else f"${tr_pc:,.2f}",
              None if pd.isna(world_pc) else f"Dünya: ${world_pc:,.1f}", delta_color="off")
    c3.metric("Dünya yatırımlarındaki konum", "Veri yok" if rank is None else f"{rank}. / {len(totals)} ülke")

    yearly_tr = investment[investment.ISO3 == TR].copy()
    yearly_tr["Milyon"] = yearly_tr.YatirimUSD / 1e6
    fig = px.bar(yearly_tr, x="Yil", y="Milyon", labels={"Yil": "Yıl", "Milyon": "Yatırım (milyon $)"})
    fig.update_traces(marker_color="#91B3A7", hovertemplate="Yıl: %{x}<br>Yatırım: %{y:,.1f} milyon $<extra></extra>")
    style_chart(fig, 320)
    with st.container(border=True): st.plotly_chart(fig, use_container_width=True)

    # Kalkınma göstergeleri: Türkiye ve dünya medyanı (FactKalkinma)
    st.markdown(f'<div class="section-kicker">KALKINMA GÖSTERGELERİ</div><div class="section-title">Dünya medyanıyla karşılaştırma ({REF_YEAR})</div><div class="section-desc">Dünya Bankası WDI; medyan, {REF_YEAR} yılında verisi olan ülkelerin medyanıdır.</div>', unsafe_allow_html=True)
    ref = development[development.Yil == REF_YEAR]
    tr_ref = ref[ref.ISO3 == TR]
    indicators = [
        ("ArGeGsyh", "Ar-Ge harcaması (% GSYH)", "{:,.2f}"),
        ("ArastirmaciMilyon", "Milyon kişide araştırmacı", "{:,.0f}"),
        ("InternetKullanim", "İnternet kullanımı (%)", "{:,.1f}"),
        ("Genisband100", "Sabit geniş bant (100 kişide)", "{:,.1f}"),
        ("KisiBasiGsyh", "Kişi başı GSYH ($)", "{:,.0f}"),
        ("YuksekogretimKayit", "Yükseköğretim kayıt (%)", "{:,.1f}"),
    ]
    cols = st.columns(3)
    for i, (col, label, fmt) in enumerate(indicators):
        tr_val = tr_ref[col].iloc[0] if len(tr_ref) else np.nan
        med = ref[col].median()
        with cols[i % 3], st.container(border=True):
            st.metric(label, "Veri yok" if pd.isna(tr_val) else fmt.format(tr_val),
                      None if pd.isna(med) else f"Dünya medyanı: {fmt.format(med)}", delta_color="off")

    # Büyük ölçekli model sayısı (FactModel): kayıt yoksa sıfır gösterilmez
    st.markdown('<div class="section-kicker">BÜYÜK ÖLÇEKLİ MODELLER</div><div class="section-title">Epoch AI model kayıtları</div>', unsafe_allow_html=True)
    positive = models_data[models_data.BuyukModelKumulatif > 0]
    tr_models = positive[positive.ISO3 == TR]
    with st.container(border=True):
        if tr_models.empty:
            st.metric("Büyük ölçekli yapay zekâ model sayısı", "Veri yok")
            st.caption(f"Epoch AI kaynağında {positive.ISO3.nunique()} ülke yer alıyor ve Türkiye kaydı bulunmuyor. Bu, Türkiye'nin hiç büyük model geliştirmediği anlamına gelmez; yalnızca bu kaynakta kayıt yoktur. Yatırım ve kalkınma göstergeleri ayrı kaynaklardan geldiği için bu eksiklikten etkilenmez.")
        else:
            last = tr_models.sort_values("Yil").iloc[-1]
            st.metric("Büyük ölçekli yapay zekâ model sayısı", f"{int(last.BuyukModelKumulatif)}", f"{int(last.Yil)} kümülatif", delta_color="off")
    st.markdown('<div class="suvera-note">Kaynaklar: CSET (yatırım), Dünya Bankası WDI (kalkınma göstergeleri, nüfus), Epoch AI (büyük model sayısı). Göstergeler Power BI raporundaki Türkiye Profili sayfasıyla aynı tablolardan ve aynı referans yılından hesaplanır. Kişi başı yatırım yalnızca nüfus verisi olan ülke-yıllar üzerinden hesaplanır.</div>', unsafe_allow_html=True)

elif page == "Yatırım Tahmini":
    st.markdown('<div class="section-kicker">SENARYO ALANI</div><div class="section-title">Ülkenin göstergelerini düzenle</div><div class="section-desc">Tahmin, seçilen hedef yıldan önceki en güncel kalkınma göstergelerini kullanır.</div>', unsafe_allow_html=True)
    countries_sorted = countries.sort_values("UlkeTR")
    labels = {f"{r.UlkeTR} ({r.ISO3})": r.ISO3 for r in countries_sorted.itertuples()}
    label_list = list(labels.keys())
    default_idx = next((i for i, v in enumerate(labels.values()) if v == "TUR"), 0)
    c1, c2 = st.columns([1.5, 1])
    with c1: selected_label = st.selectbox("Ülke", label_list, index=default_idx)
    with c2: target_year = st.selectbox("Tahmin yılı", [2026, 2027, 2028], index=0)
    iso3 = labels[selected_label]
    row, source_year = latest_country_features(tables, iso3, target_year - 1)
    if row is None:
        st.warning("Bu ülke için kullanılabilir kalkınma göstergesi bulunamadı.")
        st.stop()
    if source_year != target_year - 1:
        st.info(f"{target_year-1} yılı verisi bulunamadı. En güncel mevcut gösterge yılı ({source_year}) kullanılıyor.")

    labels_tr = {
        "Nufus":"Nüfus", "ArGeGsyh":"Ar-Ge harcaması (% GSYH)",
        "ArastirmaciMilyon":"Milyon kişiye düşen araştırmacı",
        "InternetKullanim":"İnternet kullanımı (%)", "Genisband100":"100 kişiye sabit geniş bant",
        "KisiBasiGsyh":"Kişi başına GSYH (USD)", "YuksekogretimKayit":"Yükseköğretim kayıt oranı (%)"
    }
    training = make_training_frame(tables)
    median_values = training[NUMERIC_FEATURES].median(numeric_only=True)
    missing_labels = []
    edited = row.copy()

    # Büyük model verisi: hedef yıldan bir önceki yıl.
    big_model_year = int(target_year) - 1
    big_model_rows = tables["FactModel"][
        (tables["FactModel"]["ISO3"] == iso3)
        & (tables["FactModel"]["Yil"] == big_model_year)
    ]

    if big_model_rows.empty:
        big_model_value = np.nan
    else:
        big_model_value = float(
            big_model_rows.iloc[0]["BuyukModelKumulatif"]
        )

    edited["BuyukModelKumulatif"] = big_model_value
    edited["BuyukModelVerisiEksik"] = int(
        pd.isna(big_model_value)
    )
    with st.container(border=True):
        st.markdown("**Gösterge değerleri**")
        st.caption("Değerleri değiştirebilirsin. Eksik kaynak verileri, modelin eğitim dönemindeki medyanıyla başlangıç değeri alır.")
        cols = st.columns(2)
        for i, col in enumerate(NUMERIC_FEATURES):
            if col == "Yil": continue
            raw = row.get(col, np.nan)
            missing = pd.isna(raw)
            if missing:
                missing_labels.append(labels_tr.get(col, col))
                raw = median_values.get(col, np.nan)
            if pd.isna(raw): raw = 0.0
            with cols[i % 2]:
                edited[col] = st.number_input(labels_tr.get(col, col), value=float(raw), format="%.4f", key=f"suvera_input_{iso3}_{target_year}_{col}")
    if missing_labels:
        st.warning("Kaynakta eksik olan göstergeler: " + ", ".join(missing_labels) + ". Başlangıç değerleri eğitim verisinin medyanıyla dolduruldu; istersen düzenleyebilirsin.")

    st.markdown("\n")
    if bundle.uses_big_model_feature:
        with st.container(border=True):
            st.markdown("**Büyük ölçekli yapay zekâ model verisi**")
            if pd.isna(big_model_value):
                st.warning(
                    f"{iso3} için {big_model_year} yılı büyük model verisi "
                    "bulunamadı. Değer sıfır kabul edilmeyecek; model bu ülke-yılı "
                    "'büyük model verisi eksik' olarak işleyecek. Kaynakta kayıt "
                    "bulunmaması, ülkede büyük model olmadığı anlamına gelmez."
                )
            else:
                st.metric(
                    f"{big_model_year} yılı kümülatif büyük model sayısı",
                    f"{big_model_value:,.0f}",
                )
                st.caption(
                    "Tahminde hedef yıldan bir önceki yılın kaynak değeri kullanılır."
                )

    if st.button("Tahmin senaryosunu hesapla", type="primary", use_container_width=True):
        prediction = predict_investment(bundle, iso3, target_year, edited)
        st.session_state["last_prediction"] = {"country":selected_label,"year":target_year,"value":prediction,"source_year":source_year}
    result = st.session_state.get("last_prediction")
    if result and result["country"] == selected_label and result["year"] == target_year:
        st.markdown('<div class="section-kicker">MODEL ÇIKTISI</div><div class="section-title">Senaryo tahmini</div>', unsafe_allow_html=True)
        with st.container(border=True):
            st.metric(f"{target_year} için tahmini yatırım tutarı", money_short(result["value"]))
            st.caption(f"Ülke: {selected_label} · Gösterge yılı: {result['source_year']} · Kullanılan model: {bundle.model_name}")
        st.markdown('<div class="suvera-note">Bu çıktı gerçekleşmiş yatırım verisi değil, makine öğrenmesi modelinin tahminidir. Model yalnızca veri setinde pozitif yatırım kaydı bulunan ülke-yıl örnekleriyle eğitilmiştir; yatırım kaydı oluşup oluşmayacağını tahmin etmez. Sonuç, seçilen göstergelere ve modelin sınırlı test performansına bağlıdır.</div>', unsafe_allow_html=True)
    else:
        st.info("Tahmin sonucunu görmek için senaryo hesaplama düğmesine bas.")

elif page == "Model Performansı":
    st.markdown('<div class="section-kicker">ZAMANSAL DOĞRULAMA</div><div class="section-title">Model ne kadar iyi tahmin ediyor?</div><div class="section-desc">Model geçmiş yıllarda eğitildi, daha sonraki yıllardaki kayıtlarla test edildi.</div>', unsafe_allow_html=True)
    a,b,c = st.columns(3)
    a.metric("Eğitim örneği", f"{bundle.training_rows:,}")
    b.metric("Test örneği", f"{bundle.test_rows:,}")
    b_year = int(bundle.holdout.Yil.max())
    c.metric("Test dönemi", f"{bundle.test_from}–{b_year}")
    with st.container(border=True):
        st.markdown("**Model seçimi – doğrulama dönemi (2021–2022)**")
        st.caption(
            "Aday modeller doğrulama döneminde karşılaştırıldı. "
            "Model seçimi bu dönemdeki MAE değerine göre yapıldı."
        )
        st.dataframe(
            bundle.validation_metrics.style.format({
                "MAE ($)": "${:,.0f}",
                "RMSE ($)": "${:,.0f}",
                "R²": "{:.3f}",
            }),
            use_container_width=True,
            hide_index=True,
        )

    with st.container(border=True):
        st.markdown("**Nihai test performansı (2023–2025)**")
        st.dataframe(bundle.metrics.style.format({"MAE ($)":"${:,.0f}","RMSE ($)":"${:,.0f}","R²":"{:.3f}"}), use_container_width=True, hide_index=True)
    # Dinamik performans hesaplamaları
    selected_model = bundle.metrics[
        bundle.metrics["Model"] != "Medyan Baseline"
    ].iloc[0]

    baseline_model = bundle.metrics[
        bundle.metrics["Model"] == "Medyan Baseline"
    ].iloc[0]

    mae_improvement = (
        (baseline_model["MAE ($)"] - selected_model["MAE ($)"])
        / baseline_model["MAE ($)"]
    ) * 100

    selected_validation = bundle.validation_metrics[
        bundle.validation_metrics["Model"] == selected_model["Model"]
    ].iloc[0]

    base_validation = bundle.validation_metrics[
        bundle.validation_metrics["Model"] == "Extra Trees (Temel)"
    ].iloc[0]

    validation_improvement = (
        (base_validation["MAE ($)"] - selected_validation["MAE ($)"])
        / base_validation["MAE ($)"]
    ) * 100

    st.markdown(
        '<div class="section-kicker">PERFORMANS DEĞERLENDİRMESİ</div>'
        '<div class="section-title">Model sonuçlarının özeti</div>',
        unsafe_allow_html=True,
    )

    p1, p2, p3 = st.columns(3)

    p1.metric(
        "Baseline'a göre MAE iyileşmesi",
        f"%{mae_improvement:.1f}",
    )

    p2.metric(
        "Nihai test R²",
        f"{selected_model['R²']:.3f}",
    )

    p3.metric(
        "Büyük model verisinin doğrulama katkısı",
        f"%{validation_improvement:.2f}",
    )

    st.info(
        f"Seçilen model {selected_model['Model']}, "
        f"nihai test döneminde medyan baseline modeline göre "
        f"%{mae_improvement:.1f} daha düşük MAE üretmiştir. "
        f"Büyük model verisinin temel Extra Trees modeline göre "
        f"doğrulama MAE katkısı %{validation_improvement:.2f} "
        "düzeyindedir. Nihai test R² değerinin daha düşük olması, "
        "modelin yeni dönemlere genelleme kapasitesinin "
        "geliştirilmesi gerektiğini göstermektedir."
    )

    st.caption("MAE ve RMSE düşük, R² yüksek olduğunda performans daha iyidir. R² negatif olabilir; bu, modelin test dönemindeki ortalama tahminden daha kötü olduğunu gösterir.")
    fig = px.scatter(bundle.holdout, x="YatirimUSD", y="TahminUSD", color="Yil", hover_name="UlkeTR", log_x=True, log_y=True,
                     labels={"YatirimUSD":"Gerçek yatırım (USD)","TahminUSD":"Tahmin (USD)","Yil":"Yıl"})
    fig.update_traces(marker=dict(size=8, opacity=.72))
    style_chart(fig, 440)
    with st.container(border=True):
        st.markdown("**Gerçek ve tahmin edilen yatırım tutarları**")
        st.caption("Her nokta, test dönemindeki bir ülke-yıl kaydını temsil eder. Eksenler geniş değer aralığını göstermek için logaritmiktir.")
        st.plotly_chart(fig, use_container_width=True)
    with st.container(border=True):
        st.markdown("**En yüksek mutlak hataya sahip 15 kayıt**")
        error_view = bundle.holdout.sort_values("MutlakHataUSD", ascending=False).head(15).copy()
        error_view["Gerçek yatırım"] = error_view["YatirimUSD"].map(money_short)
        error_view["Model tahmini"] = error_view["TahminUSD"].map(money_short)
        error_view["Mutlak hata"] = error_view["MutlakHataUSD"].map(money_short)
        st.dataframe(error_view[["UlkeTR","Yil","Gerçek yatırım","Model tahmini","Mutlak hata"]], use_container_width=True, hide_index=True)
    st.info(f"Eğitim dönemi: 2017–{bundle.train_until}. Test dönemi: {bundle.test_from}–{b_year}. Yatırım tutarı log(1 + USD) dönüşümüyle modellenir. Metrikler gerçek USD ölçeğinde hesaplanır.")

else:
    st.markdown('<div class="section-kicker">VERİ KATALOĞU</div><div class="section-title">Projenin veri tabloları</div><div class="section-desc">Kaynak tabloların kapsamını incele, filtrele ve CSV olarak indir.</div>', unsafe_allow_html=True)
    summary = pd.DataFrame([
        ["FactYatirim",len(tables["FactYatirim"]),tables["FactYatirim"].ISO3.nunique(),"Pozitif yatırım kaydı bulunan ülke-yıllar"],
        ["FactKalkinma",len(tables["FactKalkinma"]),tables["FactKalkinma"].ISO3.nunique(),"Kalkınma göstergeleri ve nüfus"],
        ["FactModel",len(tables["FactModel"]),tables["FactModel"].ISO3.nunique(),"Büyük ölçekli yapay zekâ model kayıtları"],
        ["DimUlke",len(tables["DimUlke"]),len(tables["DimUlke"]),"Ülke bilgileri"],
        ["DimYil",len(tables["DimYil"]),len(tables["DimYil"]),"Yıl boyutu"],
    ], columns=["Tablo","Satır sayısı","Ülke / kayıt","Açıklama"])
    with st.container(border=True): st.dataframe(summary, use_container_width=True, hide_index=True)
    data_choice = st.selectbox("İncelenecek tablo", ["FactYatirim", "FactKalkinma", "FactModel", "DimUlke", "DimYil"])
    selected_data = tables[data_choice].copy()
    filter_cols = st.columns(2)
    if "Yil" in selected_data.columns:
        years = sorted(selected_data.Yil.dropna().astype(int).unique())
        with filter_cols[0]: selected_years = st.multiselect("Yıl filtresi", years, default=years)
        selected_data = selected_data[selected_data.Yil.isin(selected_years)]
    if "ISO3" in selected_data.columns:
        available = sorted(selected_data.ISO3.dropna().unique())
        with filter_cols[1]: selected_countries = st.multiselect("Ülke kodu filtresi", available, default=[] , placeholder="Tüm ülkeler")
        if selected_countries: selected_data = selected_data[selected_data.ISO3.isin(selected_countries)]
    st.caption(f"Gösterilen kayıt: {len(selected_data):,}")
    with st.container(border=True): st.dataframe(selected_data, use_container_width=True, hide_index=True)
    st.download_button("Görüntülenen veriyi CSV indir", data=selected_data.to_csv(index=False).encode("utf-8-sig"), file_name=f"suvera_{data_choice.lower()}.csv", mime="text/csv")
    with st.expander("Makine öğrenmesi değişkenleri ve yöntem"):
        st.markdown("**Hedef değişken:** Bir sonraki yılın özel yapay zekâ yatırımı (USD).")
        st.markdown("**Girdiler:** Ülke kodu, hedef yıl ve önceki yılın nüfus, Ar-Ge, araştırmacı, internet, geniş bant, kişi başı GSYH ve yükseköğretim göstergeleri.")
        st.markdown("**Önemli sınır:** FactYatirim tablosunda satır bulunmaması sıfır yatırım anlamına gelmez. Model yatırım kaydının oluşup oluşmayacağını değil, pozitif kayıt bulunan örneklerdeki tutarı tahmin eder.")

st.markdown('<div class="suvera-footer">SUVERA · The world of AI, through data. &nbsp; | &nbsp; Bitirme projesinin CSV veri tabloları kullanılarak geliştirilmiştir.</div>', unsafe_allow_html=True)
