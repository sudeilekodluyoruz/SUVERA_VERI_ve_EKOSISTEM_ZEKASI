from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from sklearn.compose import ColumnTransformer
from sklearn.ensemble import ExtraTreesRegressor, RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


# Uygulama arayüzündeki mevcut gösterge alanları.
# Bu listeyi koruyoruz; büyük model verisi ayrıca yönetilecek.
NUMERIC_FEATURES = [
    "Yil",
    "Nufus",
    "ArGeGsyh",
    "ArastirmaciMilyon",
    "InternetKullanim",
    "Genisband100",
    "KisiBasiGsyh",
    "YuksekogretimKayit",
]

CATEGORICAL_FEATURES = ["ISO3"]
TARGET = "YatirimUSD"

# Deneysel modelde kullanılacak ek değişkenler.
BIG_MODEL_FEATURES = [
    "BuyukModelKumulatif",
    "BuyukModelVerisiEksik",
]

BASE_NUMERIC_FEATURES = NUMERIC_FEATURES.copy()
AUGMENTED_NUMERIC_FEATURES = NUMERIC_FEATURES + BIG_MODEL_FEATURES


@dataclass
class ModelBundle:
    model: Pipeline
    model_name: str
    metrics: pd.DataFrame
    validation_metrics: pd.DataFrame
    holdout: pd.DataFrame
    training_rows: int
    test_rows: int
    train_until: int
    test_from: int
    feature_year_max: int
    uses_big_model_feature: bool
    feature_columns: list[str]




def make_training_frame(
    tables: dict[str, pd.DataFrame],
) -> pd.DataFrame:
    """
    Yıl t yatırımını, yıl t-1 kalkınma ve büyük model
    göstergeleriyle tahmin etmek için eğitim tablosu oluşturur.

    Yatırım tablosundaki kayıtlar değiştirilmez.
    Eksik büyük model verisi sıfıra çevrilmez.
    """

    investment = tables["FactYatirim"].copy()
    development = tables["FactKalkinma"].copy()
    models = tables["FactModel"].copy()

    country = tables["DimUlke"][
        ["ISO3", "UlkeTR", "Kita", "GelirGrubu"]
    ].copy()

    # Yatırım yılı hedef yıl olarak adlandırılır.
    investment = investment.rename(
        columns={"Yil": "HedefYil"}
    )
    investment["HedefYil"] = investment["HedefYil"].astype(int)

    # Kalkınma göstergeleri bir önceki yıldan alınır.
    development = development.rename(
        columns={"Yil": "OzellikYili"}
    )
    development["OzellikYili"] = development[
        "OzellikYili"
    ].astype(int)
    development["HedefYil"] = development["OzellikYili"] + 1

    frame = investment.merge(
        development.drop(columns=["OzellikYili"]),
        on=["ISO3", "HedefYil"],
        how="inner",
        validate="one_to_one",
    )

    # Büyük model verisini bir yıl geriye kaydır:
    # 2022 yatırımı için 2021 büyük model sayısı kullanılır.
    models["Yil"] = models["Yil"].astype(int) + 1
    models = models.rename(columns={"Yil": "HedefYil"})

    models = models[
        ["ISO3", "HedefYil", "BuyukModelKumulatif"]
    ].copy()

    models["BuyukModelKumulatif"] = pd.to_numeric(
        models["BuyukModelKumulatif"],
        errors="coerce",
    )

    frame = frame.merge(
        models,
        on=["ISO3", "HedefYil"],
        how="left",
        validate="one_to_one",
    )

    # Eksik veri ile gerçek sıfır birbirinden ayrılır.
    frame["BuyukModelVerisiEksik"] = (
        frame["BuyukModelKumulatif"].isna().astype(int)
    )

    frame = frame.merge(
        country,
        on="ISO3",
        how="left",
        validate="many_to_one",
    )

    frame = frame.rename(columns={"HedefYil": "Yil"})

    # Yalnızca mevcut pozitif yatırım kayıtları kullanılır.
    frame = frame[
        frame[TARGET].notna() & (frame[TARGET] > 0)
    ].copy()

    frame["Yil"] = frame["Yil"].astype(int)

    return (
        frame.sort_values(["Yil", "ISO3"])
        .reset_index(drop=True)
    )


def _make_pipeline(
    estimator,
    numeric_features: list[str],
) -> Pipeline:

    numeric = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler(with_mean=False)),
        ]
    )

    categorical = Pipeline(
        steps=[
            (
                "imputer",
                SimpleImputer(strategy="most_frequent"),
            ),
            (
                "onehot",
                OneHotEncoder(handle_unknown="ignore"),
            ),
        ]
    )

    prep = ColumnTransformer(
        transformers=[
            ("numeric", numeric, numeric_features),
            (
                "categorical",
                categorical,
                CATEGORICAL_FEATURES,
            ),
        ]
    )

    return Pipeline(
        steps=[
            ("preprocess", prep),
            ("model", estimator),
        ]
    )


def _make_candidates():
    return {
        "Random Forest": RandomForestRegressor(
            n_estimators=500,
            min_samples_leaf=2,
            max_features=0.9,
            random_state=42,
            n_jobs=1,
        ),
        "Extra Trees": ExtraTreesRegressor(
            n_estimators=500,
            min_samples_leaf=2,
            max_features=0.9,
            random_state=42,
            n_jobs=1,
        ),
        "Ridge": Ridge(alpha=10.0),
    }


def _calculate_metrics(
    y_true: np.ndarray,
    predictions: np.ndarray,
    model_name: str,
) -> dict:

    return {
        "Model": model_name,
        "MAE ($)": mean_absolute_error(
            y_true, predictions
        ),
        "RMSE ($)": np.sqrt(
            mean_squared_error(y_true, predictions)
        ),
        "R²": r2_score(y_true, predictions),
    }


def train_model(
    tables: dict[str, pd.DataFrame],
) -> ModelBundle:

    data = make_training_frame(tables)

    if data.empty:
        raise ValueError(
            "Eğitim için eşleşen yatırım ve önceki yıl "
            "göstergesi bulunamadı."
        )

    # Eğitim: 2017-2020
    # Doğrulama: 2021-2022
    # Nihai test: 2023-2025
    train = data[data["Yil"].between(2017, 2020)].copy()
    validation = data[data["Yil"].between(2021, 2022)].copy()
    test = data[data["Yil"].between(2023, 2025)].copy()

    if train.empty or validation.empty or test.empty:
        raise ValueError(
            "Eğitim, doğrulama ve test dönemlerinden "
            "en az biri boş. Veri yıllarını kontrol et."
        )

    y_train = np.log1p(train[TARGET].astype(float))
    y_validation = validation[TARGET].astype(float)

    candidate_results = []
    fitted_candidates = {}

    # Altı aday aynı eğitim ve doğrulama kayıtlarıyla karşılaştırılır.
    for feature_type, numeric_features in [
        ("Temel", BASE_NUMERIC_FEATURES),
        ("Büyük Model Ekli", AUGMENTED_NUMERIC_FEATURES),
    ]:

        feature_columns = (
            numeric_features + CATEGORICAL_FEATURES
        )

        X_train = train[feature_columns]
        X_validation = validation[feature_columns]

        for model_name, estimator in _make_candidates().items():

            full_name = f"{model_name} ({feature_type})"

            pipe = _make_pipeline(
                estimator,
                numeric_features,
            )

            pipe.fit(X_train, y_train)

            predictions = np.maximum(
                0,
                np.expm1(pipe.predict(X_validation)),
            )

            result = _calculate_metrics(
                y_validation.to_numpy(),
                predictions,
                full_name,
            )

            candidate_results.append(result)

            fitted_candidates[full_name] = {
                "pipeline": pipe,
                "feature_columns": feature_columns,
                "uses_big_model_feature": (
                    feature_type == "Büyük Model Ekli"
                ),
            }

    validation_metrics = (
        pd.DataFrame(candidate_results)
        .sort_values("MAE ($)")
        .reset_index(drop=True)
    )

    # Model seçimi yalnızca 2021-2022 doğrulama MAE
    # değerine göre yapılır. Nihai test kullanılmaz.
    best_name = validation_metrics.iloc[0]["Model"]
    selected = fitted_candidates[best_name]

    # Seçilen model, eğitim + doğrulama verisiyle yeniden eğitilir.
    final_train = pd.concat(
        [train, validation],
        ignore_index=True,
    )

    feature_columns = selected["feature_columns"]
    X_final_train = final_train[feature_columns]
    y_final_train = np.log1p(
        final_train[TARGET].astype(float)
    )

    final_model = _make_pipeline(
        _make_candidates()[
            best_name.split(" (")[0]
        ],
        (
            AUGMENTED_NUMERIC_FEATURES
            if selected["uses_big_model_feature"]
            else BASE_NUMERIC_FEATURES
        ),
    )

    final_model.fit(X_final_train, y_final_train)

    # Nihai test ilk kez burada değerlendirilir.
    X_test = test[feature_columns]
    y_test = test[TARGET].astype(float)

    test_predictions = np.maximum(
        0,
        np.expm1(final_model.predict(X_test)),
    )

    selected_test_metrics = _calculate_metrics(
        y_test.to_numpy(),
        test_predictions,
        best_name,
    )

    # Test dönemi için karşılaştırma tabanı:
    # Eğitim + doğrulama hedeflerinin medyanı.
    baseline_value = float(
        np.expm1(np.median(y_final_train))
    )

    baseline_predictions = np.full(
        len(test),
        baseline_value,
        dtype=float,
    )

    baseline_test_metrics = _calculate_metrics(
        y_test.to_numpy(),
        baseline_predictions,
        "Medyan Baseline",
    )

    metrics = pd.DataFrame(
        [selected_test_metrics, baseline_test_metrics]
    ).sort_values("MAE ($)").reset_index(drop=True)

    holdout = test[
        ["ISO3", "UlkeTR", "Yil", TARGET]
    ].copy()

    holdout["TahminUSD"] = test_predictions
    holdout["MutlakHataUSD"] = np.abs(
        holdout[TARGET] - holdout["TahminUSD"]
    )

    return ModelBundle(
        model=final_model,
        model_name=best_name,
        metrics=metrics,
        validation_metrics=validation_metrics,
        holdout=holdout,
        training_rows=len(final_train),
        test_rows=len(test),
        train_until=int(final_train["Yil"].max()),
        test_from=int(test["Yil"].min()),
        feature_year_max=int(data["Yil"].max() - 1),
        uses_big_model_feature=selected[
            "uses_big_model_feature"
        ],
        feature_columns=feature_columns,
    )


def predict_investment(
    bundle: ModelBundle,
    iso3: str,
    target_year: int,
    feature_row: pd.Series | dict,
) -> float:

    row = {
        col: feature_row.get(col, np.nan)
        for col in NUMERIC_FEATURES
    }

    row["Yil"] = int(target_year)
    row["ISO3"] = iso3

    if bundle.uses_big_model_feature:
        big_model_value = feature_row.get(
            "BuyukModelKumulatif",
            np.nan,
        )

        row["BuyukModelKumulatif"] = big_model_value
        row["BuyukModelVerisiEksik"] = int(
            pd.isna(big_model_value)
        )

    X = pd.DataFrame(
        [row],
        columns=bundle.feature_columns,
    )

    prediction = bundle.model.predict(X)[0]

    return float(max(0.0, np.expm1(prediction)))
