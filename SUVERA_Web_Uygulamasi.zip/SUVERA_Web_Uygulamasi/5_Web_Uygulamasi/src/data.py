from pathlib import Path
import pandas as pd


def get_data_dir() -> Path:
    return Path(__file__).resolve().parents[2] / "3_Veri"


def load_app_data():
    root = get_data_dir()
    tables = {
        name: pd.read_csv(root / f"{name}.csv")
        for name in ["FactYatirim", "FactKalkinma", "FactModel", "DimUlke", "DimYil"]
    }
    return tables


def latest_country_features(tables, iso3: str, before_year: int):
    data = tables["FactKalkinma"]
    rows = data[(data["ISO3"] == iso3) & (data["Yil"] <= before_year)].sort_values("Yil")
    if rows.empty:
        return None, None
    return rows.iloc[-1].copy(), int(rows.iloc[-1]["Yil"])
