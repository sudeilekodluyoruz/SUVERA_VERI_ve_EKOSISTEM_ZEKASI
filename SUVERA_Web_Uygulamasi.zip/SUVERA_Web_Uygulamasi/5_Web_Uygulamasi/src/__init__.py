"""AI Ecosystem Intelligence application package."""
