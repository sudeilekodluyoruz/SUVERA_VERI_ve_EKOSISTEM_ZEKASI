# SUVERA — Data & Ecosystem Intelligence

Yapay Zekâ Ekosistemi bitirme projesinin `3_Veri` klasöründeki CSV tablolarını kullanan, SUVERA görsel kimliğiyle geliştirilmiş Streamlit web uygulaması.

**Slogan:** The world of AI, through data.

**Tasarım:** Kırık beyaz, adaçayı ve yumuşak petrol tonları; okunabilir tipografi ve sade veri kartları.

## Özellikler
- Genel bakış ve ülke/yıl yatırım grafikleri
- Türkiye Profili: yatırım, kişi başı yatırım, dünya sırası, kalkınma göstergeleri ve dünya medyanı; büyük model sayısı kayıt yoksa "veri yok" olarak gösterilir
- Önceki yılın kalkınma göstergeleriyle sonraki yılın pozitif yatırım kaydı tutarını tahmin etme
- Extra Trees ve Random Forest model karşılaştırması (temel ve büyük model ekli özellik setleri)
- Zamansal ayrım: 2017–2020 eğitim, 2021–2022 doğrulama, 2023–2025 test
- Filtrelenebilir veri merkezi ve CSV dışa aktarma
- Eksik tahmin girdilerini eğitim verisinin medyanıyla doldurma ve kullanıcıya açıkça bildirme
- Tutarlı para birimi gösterimi ve sade, pastel arayüz

## Kurulum
Proje kök klasöründe terminal aç:

```bash
python -m venv .venv
```

Windows PowerShell:
```powershell
.venv\Scripts\Activate.ps1
pip install -r 5_Web_Uygulamasi/requirements.txt
python -m streamlit run 5_Web_Uygulamasi/app.py
```

macOS / Linux:
```bash
source .venv/bin/activate
pip install -r 5_Web_Uygulamasi/requirements.txt
python -m streamlit run 5_Web_Uygulamasi/app.py
```

## Tahmin metodolojisi ve önemli sınırlama
Hedef değişken, hedef yıldaki `FactYatirim.YatirimUSD` değeridir. Özellikler hedef yıldan bir önceki yılın `FactKalkinma` tablosundan alınır. Eğitim/test ayrımı kronolojiktir: 2017–2022 eğitim, 2023–2025 test. Hedef log(1 + USD) dönüşümüyle eğitilir; performans metrikleri USD ölçeğinde raporlanır.

`FactYatirim` yalnızca pozitif yatırım kaydı bulunan ülke-yılları içerir. Satır bulunmaması sıfır yatırım anlamına gelmediği için model yatırımın gerçekleşip gerçekleşmeyeceğini değil, pozitif kayıt bulunan ülke-yıllardaki yatırım tutarını tahmin eder. Gelecek yıl için gösterge verisi yoksa uygulama ülkenin en güncel mevcut yılını kullanır ve bunu kullanıcıya bildirir. Bu nedenle çıktı kesin finansal öngörü değil, senaryo tabanlı analitik tahmindir.
