# Makine Öğrenmesi Model Notları

## Problem tanımı
Model, bir ülkenin hedef yıldaki pozitif özel yapay zekâ yatırım kaydı tutarını (`YatirimUSD`) tahmin etmeyi dener. Girdiler hedef yıldan bir önceki yılın kalkınma göstergeleri ve büyük ölçekli model verisidir.

## Veri hazırlığı
- Hedef yıl: 2017–2025; eşleşen örnek: 639 ülke-yıl, 106 ülke
- Eğitim: 2017–2020, doğrulama: 2021–2022 (model seçimi), nihai test: 2023–2025 (234 örnek). Seçilen model eğitim + doğrulama ile yeniden eğitilir.
- Hedef dönüşümü: `log(1 + YatirimUSD)`; eksik sayısal değerler eğitim verisinin medyanıyla doldurulur; ülke kodu One-Hot Encoding.
- Aday modeller: Extra Trees ve Random Forest, her biri "Temel" ve "Büyük Model Ekli" özellik setiyle; ayrıca medyan baseline.

## Sonuç (nihai test, 2023–2025)
| Model | MAE (USD) | RMSE (USD) | R² |
|---|---:|---:|---:|
| Extra Trees (Büyük Model Ekli) | 2.321.120.000 | 19.614.240.000 | 0,249 |
| Medyan Baseline | 3.379.525.000 | 22.870.150.000 | -0,022 |

## Büyük ölçekli model verisi ve Türkiye
- `FactModel` (Epoch AI) yalnızca 20 ülkeyi kapsar; Türkiye bu tabloda yoktur. Kayıt bulunmaması, Türkiye'de büyük model olmadığı anlamına gelmez; bu nedenle sıfır olarak gösterilmez, "veri yok" olarak ele alınır.
- Modelde `BuyukModelKumulatif` değeri yoksa `BuyukModelVerisiEksik = 1` bayrağı kullanılır. Eğitim örneklerinin 527'si (639 içinden) bu bayrağı taşıdığı için bayrak fiilen "ülke Epoch AI listesinde yok" bilgisini taşır. Yani model Türkiye gibi ülkelerde büyük model verisini bilgi olarak değil, eksiklik işareti olarak kullanır.
- Türkiye'nin yatırım ve kalkınma göstergeleri (FactYatirim, FactKalkinma) bu eksiklikten etkilenmez ve Türkiye Profili sayfasında korunur.

## Yorum ve sınırlamalar
- Model medyan baseline'dan daha düşük MAE üretir, ancak R² düşüktür; sonuçlar kesin öngörü olarak yorumlanmamalıdır.
- Yatırım tutarlarının dağılımı çok çarpıktır; az sayıdaki çok büyük yatırım hata metriklerini belirgin biçimde etkiler.
- `FactYatirim` yalnızca pozitif yatırım kaydı olan ülke-yılları içerir; kayıt yokluğu sıfır yatırım olarak kodlanmaz. Model yatırımın olup olmayacağını değil, kayıt bulunan örneklerdeki tutarı tahmin eder.
- Ülke bazlı doğrulama, daha uzun tarihsel veri ve belirsizlik aralıkları sonraki adımlardır.
